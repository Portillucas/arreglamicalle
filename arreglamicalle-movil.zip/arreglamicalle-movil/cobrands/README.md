This directory contains cobrand-related assets that aren't part of the app, for example
app store artwork and configuration files used for app store builds.
