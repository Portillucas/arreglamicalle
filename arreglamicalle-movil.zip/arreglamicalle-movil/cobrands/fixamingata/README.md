# FixaMinGata-specific commands

- <code>ln -s cobrands/fixamingata/config.xml config.xml</code>
- <code>ln -s ../../cobrands/fixamingata/config.js www/js/config.js</code>
- <code>compass compile -c www/cobrands/fixamingata/css/config.rb</code>
